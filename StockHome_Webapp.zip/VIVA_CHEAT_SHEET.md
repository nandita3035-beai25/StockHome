# Complete Viva Voce Cheat Sheet
## Smart Inventory Demand Predictor ("Mall of Tomorrow")
### Backend Architecture + Swing/AWT Graphical Frontend

Use this guide for fast revision before your college practical examination and project viva. It covers both the core Java backend (Lectures 1–14) and the Swing/AWT graphical frontend.

---

### 1. GUI Component & Swing Concept Map (`com.mall.ui.gui`)

| Class | Primary Swing / AWT Concept Demonstrated | Viva Explanation |
| :--- | :--- | :--- |
| `GuiMain` | **`SwingUtilities.invokeLater`** | Ensures all Swing components are constructed and mutated strictly on the Event Dispatch Thread (EDT). |
| `SplashScreen` | **`JWindow`, `javax.swing.Timer`, `Graphics2D`** | Displays borderless splash; uses a 35ms `Timer` to animate a rising metal shutter and illuminate neon letters. |
| `MainFrame` | **`JFrame`, `BorderLayout`, `CardLayout`, `WindowAdapter`** | Main shell; uses `CardLayout` to switch between screens smoothly without re-instantiating panels; stops simulation on window close. |
| `Theme` | **Look & Feel, Color Theory, Factory Methods** | Provides dynamic Light/Dark mode, color constants (`GOLD`, `TEAL`, `RED_ALERT`), and antialiased card painters. |
| `InventoryListener` | **Observer Design Pattern** | Decouples GUI views from backend model; any panel can subscribe to inventory change events. |
| `GuiMediator` | **Mediator Pattern & Thread-Safe Dispatch** | Coordinates navigation, delivery truck dispatches, and marshals background simulation events onto the EDT. |
| `SidebarPanel` | **Custom `JButton`, State Highlighting** | Left navigation bar; paints active gold indicator pills and live mall health badges. |
| `TickerPanel` | **Marquee Text Animation with `Timer`** | Bottom scrolling marquee displaying active critical alerts and recent audit entries. |
| `MallMapPanel` | **Custom `Graphics2D` Painting, Sprite Animation** | Paints 4 storefronts, central atrium, fountains, 8 walking shopper figures, and a sliding delivery truck. |
| `DashboardPanel` | **Pure Java 2D Charting, Count-Up Timers** | Paints custom Bar Chart, Line Chart with gradient fill, and stockout gauges without any third-party library. |
| `ProductsPanel` | **`JTable`, `TableCellRenderer`, Dialogs** | Custom table rendering visual progress bars and colored pills; catches custom checked exceptions in friendly dialogs. |
| `ReorderPanel` | **`PriorityQueue` Integration, `TableCellEditor`** | Renders Min-Heap reorders in priority sequence; contains interactive "Mark as Ordered" buttons. |
| `ReportsPanel` | **`JTabbedPane`, `JSlider`, `ChangeListener`** | Interactive demand multiplier slider dynamically recalculating predictions across 4 analytical report tabs. |
| `SimulationPanel`| **`Thread` vs `Timer`, Concurrency Synchronization** | Controls background `SimulationService` worker thread while displaying live counters and depleting stock bars. |

---

### 2. High-Frequency Swing & GUI Viva Questions

#### Q1: What is the Event Dispatch Thread (EDT) and why is `SwingUtilities.invokeLater()` essential?
> **Answer**: Swing is a single-threaded GUI framework. All component creation, layout calculation, and repainting must happen on one dedicated thread called the **Event Dispatch Thread (EDT)**. If a background worker thread modifies a Swing component directly, race conditions and screen flickering occur. We use `SwingUtilities.invokeLater(Runnable)` to post tasks to the AWT system event queue so the EDT processes them safely.

#### Q2: What is the difference between `java.lang.Thread` and `javax.swing.Timer`? Where did you use each?
> **Answer**:
> - **`java.lang.Thread`**: Runs concurrently on a separate operating system thread outside the EDT. We used it in `SimulationService` so continuous simulated customer purchasing does not freeze or block the user interface.
> - **`javax.swing.Timer`**: Fires `ActionEvent`s repeatedly **directly on the Event Dispatch Thread**. We used it for all GUI animations:
>   1. `SplashScreen`: Rolling the shutter up every 35ms.
>   2. `MallMapPanel`: Moving walking shoppers and pulsing red store alert glows at 30 FPS.
>   3. `TickerPanel`: Scrolling marquee text every 40ms.
>   4. `DashboardPanel`: Digital clock updates and count-up metric numbers.

#### Q3: How did you implement custom charts without external libraries?
> **Answer**: We overrode `paintComponent(Graphics g)` and cast the `Graphics` context to `Graphics2D`. By enabling `RenderingHints.KEY_ANTIALIASING`, we used:
> - `fillRoundRect()` and `drawRoundRect()` for the **Top Sellers Bar Chart** and stockout timeline gauges.
> - `drawLine()` and `fillPolygon()` with translucent alpha colors (`new Color(0, 229, 255, 35)`) for the **14-Day Sales Line Chart** with an area fill under the curve.

#### Q4: How does the Observer Pattern (`InventoryListener`) and Mediator Pattern (`GuiMediator`) work in this project?
> **Answer**: 
> - **Observer Pattern**: `InventoryListener` defines `onInventoryUpdated()`. All panels (`MallMapPanel`, `ProductsPanel`, `DashboardPanel`, etc.) implement this interface and register with `GuiMediator`.
> - **Mediator Pattern**: Whenever an inventory modification occurs (e.g. sale recorded, product restocked, or demand multiplier adjusted), `GuiMediator.notifyInventoryUpdated()` fires. This notifies all registered panels simultaneously on the EDT, ensuring the entire GUI updates consistently.

#### Q5: How does `JTable` rendering and interactive cell editing work?
> **Answer**:
> - **`TableCellRenderer`**: Used in `ProductsPanel` and `ReorderPanel` to customize cell appearance. For example, `StockBarRenderer` draws a rounded rectangle fill bar inside the table cell, and `UrgencyBadgeRenderer` paints a colored pill.
> - **`TableCellEditor`**: Extends `AbstractCellEditor` in `ReorderPanel` to embed interactive "Mark as Ordered" buttons inside table rows. When clicked, it captures the row data and dispatches the restock transaction.

#### Q6: How do you prevent race conditions between the background simulation thread and the Swing UI?
> **Answer**:
> 1. All stock-mutating methods in `InventoryManager` (`recordSale`, `restockProduct`) are declared **`synchronized`**, guarding them with intrinsic object locks.
> 2. The simulation thread communicates status via thread-safe getters in `SimulationService` and `volatile boolean running`.
> 3. The GUI reads values on the EDT via a `Timer` polling loop, ensuring non-blocking, thread-safe synchronization.

---

### 3. Core Backend Viva Questions (Refresher)

- **Abstract Class vs Interface**: `Product` is an abstract class because it holds concrete shared fields (`id`, `stock`, `salesHistory`) and methods (`deductStock()`), while leaving `calculateSafetyStock()` abstract for polymorphic subclasses (`PerishableProduct` vs `NonPerishableProduct`). `Predictable` is an interface providing the mathematical contract.
- **PriorityQueue for Urgency**: Implemented as a Min-Heap. By implementing `Comparable<ReorderSuggestion>`, `PriorityQueue.poll()` always extracts the single most critical, stockout-imminent item first ($O(1)$ retrieval).
- **Deque for Undo**: Follows LIFO (Last-In, First-Out) stack semantics. `ArrayDeque` is used over legacy `Stack` because it is faster and unsynchronized.
- **Checked Exceptions**: `OutOfStockException`, `InvalidQuantityException`, and `ProductNotFoundException` extend `Exception`, forcing compile-time handling via `try/catch` and displaying user-friendly dialogs instead of crashing.
- **2D Arrays**: `char[9][45]` in `MallMapRenderer` and `int[4][14]` in `DemandPredictor` for zone-wise daily sales matrix analysis with row and column totals.
