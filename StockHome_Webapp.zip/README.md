# 🏠 StockHome - 2D Animated Smart Inventory & Demand Predictor Mall

**StockHome** is a client-side web application featuring an animated 2D cartoon shopping mall theme. It requires **no compiler**, **no build tools**, **no database**, and **no server setup**. You can run it instantly by opening `index.html` in any web browser!

---

## 🌟 Key Highlights & Features

### 🏬 1. Interactive 2D Cartoon Mall Map
- **4 Animated Storefronts**:
  - 🍔 **Gourmet Food Court** (`FOOD`): Artisan Burgers, Truffle Pizzas, Boba Teas (Perishables).
  - 💻 **TechNova Electronics** (`ELEC`): ANC Earbuds, Smartwatches, RGB Keyboards (Warrantied Tech).
  - 👗 **Vogue & Velvet Fashion** (`FASH`): Denim Jackets, Organic Tees, Winter Hoodies (Apparel).
  - 🍎 **Apex Super Grocery** (`GROC`): Organic Milk, Sourdough Loaf, Himalayan Pink Salt (Daily Groceries).
- **Store Health Glow**: Stores glow **Green** (Safe), **Amber** (Warning), or **Red** (Critical). Stores in critical state display a **pulsing alert halo**.
- **Cute Cartoon Shoppers**: Animated chibi shoppers wander the promenade, visit shops, show thought bubbles with food/gadget emojis, and carry shopping bags.
- **Delivery Courier Truck**: Placing an order triggers a delivery truck with spinning wheels that drives across the mall to replenish inventory with bouncing crates!
- **Store Inspection Modal**: Click any storefront to open an inspection view of its shelves and buy items directly.

---

### 📊 2. Executive Analytics Dashboard
- **Count-Up KPI Cards**: Total SKUs, Critical Alerts, Warning Buffers, and Total Units Sold animate smoothly on load.
- **Top Sellers Bar Chart**: Pure HTML5 Canvas bar chart ranking top products by historical sales volume.
- **14-Day Sales Trend Line Chart**: Area chart with glowing translucent gradient fill plotting the daily mall-wide footfall matrix.
- **Stockout Depletion Horizon Gauges**: Color-coded timeline bars showing exact days left before depletion.

---

### 🛒 3. Store Shelves & Transactions
- **Interactive Product Catalog**: Filter by Zone (Food, Tech, Fashion, Grocery), Health Tier, or live search query.
- **Transaction Actions**:
  - `💰 Record Sale`: Sells units, plays a cash register *ka-ching* sound, and floats coin bubbles `+$14.99`!
  - `📦 Restock`: Adds units and dispatches the animated courier truck.
  - `↩️ Undo Last Sale`: LIFO transaction stack reverting previous sales.
  - `✨ Add SKU`: Add Perishable goods (with shelf life) or Non-Perishable goods (with warranty).

---

### ⚠️ 4. Priority Reorder Queue (PriorityQueue Min-Heap)
- Evaluates stock using industrial operations research:
  $$\text{Reorder Point (ROP)} = (\text{Adjusted Demand} \times \text{Lead Time}) + \text{Safety Buffer}$$
- Ranked in priority sequence: `CRITICAL` items first, then `WARNING`, then `SAFE`, prioritized by days until stockout.
- Includes **"🚚 Order Now"** buttons and a **"🚀 1-Click Order All Critical"** batch button that dispatches delivery couriers to all endangered shops.

---

### 📈 5. Demand Multiplier Sandbox & 2D Matrix
- **Weekend & Festival Footfall Surge Multiplier (1.0x to 2.5x)**: Real-time slider simulating peak holiday rushes. Moving the slider dynamically recalculates demand rates and stockout timelines everywhere!
- **Analytical Tabs**: Top Sellers by Revenue, Slow Movers by velocity, Dead Stock (with tied-up working capital calculations), and the **2D Zone Sales Matrix** ($4 \text{ zones} \times 14 \text{ days}$) with row and column totals.

---

### 🎮 6. Live Mall Simulation
- Automates live customer shopping footfall. Shoppers spawn, walk to stores, and purchase 1–3 units.
- Speed controls: 1x (1s interval), 2x (0.5s interval), and 5x (Turbo).
- Real-time depletion gauges showing inventory draining live.
- Live cash register feed logging every checkout and stockout incident.

---

### 🔊 7. Built-in Web Audio Synthesizer
- Zero MP3/WAV files needed! Synthesizes 8-bit sound effects directly via the **Web Audio API**:
  - Cash register *ka-ching* upon purchase
  - Delivery truck *beep-beep* upon restock
  - Alert chimes for critical stockouts
  - Bubble pops for menu interactions
- Sound can be toggled on/off with one click.

---

## 🚀 How to Run (Zero Setup / No Compiler Needed!)

### On Windows
- Simply double-click **`open_webapp.bat`**
- Or double-click **`index.html`** in your file explorer.

### On macOS / Linux
- Double-click **`index.html`** in your browser.
- Or run:
  ```bash
  chmod +x open_webapp.sh
  ./open_webapp.sh
  ```

---

## 📁 Project File Structure

```
StockHome/
├── index.html            # Main web application markup & modal dialogs
├── style.css             # Colorful 2D cartoon mall styling & animations
├── app.js                # Core state, math algorithms, 2D canvas engine, and Web Audio
├── open_webapp.bat       # 1-click launcher for Windows
├── open_webapp.sh        # 1-click launcher for macOS / Linux
├── README.md             # Project overview & documentation
└── VIVA_CHEAT_SHEET.md   # Mathematical formulas & viva study guide
```
