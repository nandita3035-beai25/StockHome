# Smart Inventory Demand Predictor (Mall of Tomorrow)

A comprehensive Java retail inventory forecasting system with dual interfaces:
1. **Desktop Graphical Interface (Swing & AWT)**: Modern deep navy & gold mall theme, animated rising shutter splash screen, custom-painted top-down 2D mall map with animated shoppers, executive analytics charts, interactive tables, and live multi-threaded simulation.
2. **Terminal Console Interface**: Pure ASCII animations, typed welcome banner, and interactive 12-option menu.

Strictly built on core **Java 8 basics** (no external libraries, no JavaFX, no Spring, no databases, no streams/lambdas beyond standard comparators/listeners).

---

## 🏬 Theme & Visual Design: "Mall of Tomorrow"

- **Theme Palette**: Deep Navy background (`#0B111E`), Gold accents (`#E5B842`), Neon Teal highlights (`#00E5FF`), Safe Green (`#34C759`), Amber Warning (`#FFB300`), and Critical Red (`#FF3B30`).
- **Light / Dark Mode**: One-click toggle in the top header.
- **Splash Screen**: 2-second grand opening sequence featuring an animated security shutter rolling upwards to reveal the neon illuminated sign `MALL OF TOMORROW`.
- **Main Dashboard**: Top header with branding and live digital clock, left collapsible sidebar, center screen area with card transitions, and bottom live scrolling ticker of critical alerts and recent transactions.

---

## 🖥️ Graphical Screens (com.mall.ui.gui)

1. **🏬 Mall Map (Home Screen)**:
   - Custom-painted 2D top-down floor plan (`Graphics2D`) showing 4 zones:
     - `FOOD`: Gourmet Food Court (Perishables)
     - `ELEC`: TechNova Electronics (Durable Tech)
     - `FASH`: Vogue & Velvet Fashion (Apparel)
     - `GROC`: Apex Super Grocery (Daily Essentials)
   - Storefronts glow Green (Safe), Amber (Warning), or Red (Critical). Red stores have an active **pulsing alert halo**.
   - **Animated Shoppers**: Small customer sprites walk along the promenade and enter shops.
   - **Delivery Truck Courier**: Slides from the entrance to a storefront when a reorder is placed.
   - **Interactive Hover & Click**: Hovering reveals store metrics; clicking navigates directly to that store's product catalog.
2. **📊 Executive Dashboard**:
   - Summary metric cards with **count-up animation** on load (Total SKUs, Critical Alerts, Warnings, Total Units Sold).
   - Custom **Top Sellers Bar Chart** (volume breakdown with percentage fills).
   - Custom **14-Day Mall Sales Line Chart** (plotted from 2D sales matrix with translucent gradient area fill).
   - Custom **Stockout Depletion Horizon Bar Chart** (days left until zero stock).
3. **📦 Products Catalog & Transactions**:
   - Custom `JTable` with visual progress bars and color-coded urgency pills.
   - Dynamic real-time search box and Zone Category filter dropdown.
   - **Transaction Action Buttons**:
     - `+ Record Sale`: Validates inputs and catches custom `OutOfStockException`, `InvalidQuantityException`, and `ProductNotFoundException` in friendly dialogs.
     - `^ Restock`: Adds units and triggers the animated courier truck on the Mall Map.
     - `Undo Last Sale`: Pops most recent sale from LIFO `Deque` stack and restores inventory.
     - `+ Add Product`: Guided form for Perishable (shelf life) vs Non-Perishable (warranty) goods.
     - `- Remove`: Confirms and removes SKUs.
4. **⚠️ Reorder Queue (PriorityQueue Min-Heap)**:
   - Extracted directly from `inventoryManager.generateUrgencyQueue()` (`PriorityQueue<ReorderSuggestion>`).
   - Highest-urgency items appear at the top.
   - Displays current stock, supplier lead times, safety buffers, days left, suggested reorder batch sizes, and mathematical rationales.
   - **"Mark as Ordered"** button automatically replenishes stock and dispatches the delivery truck animation.
5. **📈 Analytics Reports & Event Multiplier**:
   - **Weekend / Festival Demand Multiplier Slider (1.0x to 2.0x)**: Real-time demand surge sandbox. Adjusting the slider dynamically recalculates forecasts and stockout timelines everywhere!
   - Sub-tabs for **Top Sellers** (by volume and revenue), **Slow Movers** (by sales velocity), **Dead Stock** (zero sales with tied-up capital calculation), and the **Multi-Dimensional 2D Zone Sales Matrix** (Zones $\times$ 14 Days with row & column totals).
6. **⚡ Live Multi-Threaded Simulation**:
   - Start / Stop worker thread (`SimulationService implements Runnable`) simulating live customer footfall every 1000ms.
   - Real-time animated product stock bars that visibly deplete as customers purchase items.
   - Live counters for Ticks, Purchases Fulfilled, and Stockout Rejections.
   - Thread safely stops with `interrupt()` and `join()`.

---

## 🛠️ How to Compile and Run

No build tools or IDEs required. Works with standard `javac` and `java` (JDK 8 or higher).

### Quick Runners
```cmd
:: Launch Graphical Interface (Swing/AWT):
run.bat

:: Launch Terminal Console Interface:
run.bat --console
```

On macOS / Linux:
```bash
chmod +x run.sh

# Launch Graphical Interface:
./run.sh

# Launch Terminal Console Interface:
./run.sh --console
```

### Manual Commands
```bash
# Compile all files into bin/
javac -d bin src/com/mall/*.java src/com/mall/*/*.java src/com/mall/ui/gui/*.java

# Run Graphical Interface:
java -cp bin com.mall.ui.gui.GuiMain

# Run Console Interface:
java -cp bin com.mall.Main
```

---

## 📚 Swing / GUI Architecture & Concept Mapping

| GUI Class | Swing / AWT Concept Demonstrated | Description & Viva Notes |
| :--- | :--- | :--- |
| `Theme.java` | **Look & Feel, Color Theory, Factory Methods** | Centralized palette, dark/light theme switching, and custom rounded card painters with `Graphics2D` antialiasing. |
| `InventoryListener.java`| **Observer Design Pattern** | Decouples GUI views from backend mutations; notifies components on the Event Dispatch Thread (EDT). |
| `GuiMediator.java` | **Mediator Pattern, Multithreading Bridge** | Central coordinator managing `InventoryManager`, navigation, and thread-safe EDT dispatches (`SwingUtilities.invokeLater`). |
| `SplashScreen.java` | **JWindow, javax.swing.Timer Animation** | Borderless splash window with animated security shutter rolling upwards and neon sign lighting up. |
| `MainFrame.java` | **JFrame, BorderLayout, CardLayout, WindowAdapter**| Main window shell with header, sidebar, card container, digital clock timer, and clean thread shutdown on window close. |
| `SidebarPanel.java` | **Custom JButtons, Component State** | Left navigation bar with active button indicators, hover animations, and live mall health badge. |
| `TickerPanel.java` | **Timer-driven Marquee Animation** | Bottom scrolling marquee displaying critical stock alerts and audit trail. |
| `MallMapPanel.java` | **Graphics2D Custom Painting, Mouse Events, Sprite Animation** | Top-down floor plan with pulsing store glows, 8 wandering shopper sprites, courier delivery truck, and interactive hover tooltips. |
| `DashboardPanel.java` | **Graphics2D Charting, Count-Up Timers** | Pure Java 2D bar and line charts (zero chart libraries) and animated count-up KPI cards. |
| `ProductsPanel.java` | **JTable, DefaultTableModel, TableCellRenderer**| Interactive catalog with animated stock bars, colored urgency badges, search filtering, and custom exception dialogs. |
| `ReorderPanel.java` | **PriorityQueue Integration, TableCellEditor** | Renders Min-Heap reorder suggestions with embedded interactive "Mark as Ordered" action buttons. |
| `ReportsPanel.java` | **JTabbedPane, JSlider, ChangeListener** | Dynamic demand multiplier slider triggering real-time recalculations across 4 analytical report tabs. |
| `SimulationPanel.java`| **Thread vs Timer, Concurrency Synchronization** | Controls background `SimulationService` worker thread with live counter sync and depleting stock gauges. |
| `GuiMain.java` | **SwingUtilities.invokeLater, Entry Point** | Safely launches the GUI on the Event Dispatch Thread (EDT). |
